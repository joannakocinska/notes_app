package com.example.notes_app;

import android.content.Context;
import android.view.*;
import android.widget.*;
import java.util.List;

public class NoteAdapter extends ArrayAdapter<Note> {
    public NoteAdapter(Context context, List<Note> notes) {
        super(context, 0, notes);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Note note = getItem(position);
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(android.R.layout.simple_list_item_2, parent, false);
        }
        ((TextView) convertView.findViewById(android.R.id.text1)).setText(note.title);
        ((TextView) convertView.findViewById(android.R.id.text2)).setText(note.content);
        return convertView;
    }
}
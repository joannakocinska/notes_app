package com.example.notes_app;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.*;

public class MainActivity extends AppCompatActivity {
    List<Note> notes = new ArrayList<>();
    NoteAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView listView = findViewById(R.id.listViewNotes);
        Button btnAdd = findViewById(R.id.btnAddNote);

        // Dodaj 3 przykładowe notatki
        notes.add(new Note("Notatka", "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."));
        notes.add(new Note("Notatka", "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."));
        notes.add(new Note("Notatka", "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."));
        notes.add(new Note("Notatka", "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."));
        notes.add(new Note("Notatka", "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."));
        notes.add(new Note("Notatka", "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."));
        notes.add(new Note("Notatka", "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."));
        notes.add(new Note("Notatka", "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat."));

        adapter = new NoteAdapter(this, notes);
        listView.setAdapter(adapter);

        btnAdd.setOnClickListener(v -> showAddNoteDialog());


        listView.setOnItemClickListener((parent, view, position, id) -> {
            Note note = notes.get(position);
            new AlertDialog.Builder(this)
                    .setTitle(note.title)
                    .setMessage(note.content)
                    .setPositiveButton("OK", null)
                    .setNeutralButton("Edytuj", (dialog, which) -> showEditNoteDialog(position))
                    .setNegativeButton("Usuń", (dialog, which) -> {
                        notes.remove(position);
                        adapter.notifyDataSetChanged();
                    })
                    .show();
        });
    }

    private void showAddNoteDialog() {
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_add_note, null);
        EditText etTitle = dialogView.findViewById(R.id.etTitle);
        EditText etContent = dialogView.findViewById(R.id.etContent);

        new AlertDialog.Builder(this)
                .setTitle("Nowa notatka")
                .setView(dialogView)
                .setPositiveButton("Dodaj", (dialog, which) -> {
                    String title = etTitle.getText().toString();
                    String content = etContent.getText().toString();
                    notes.add(new Note(title, content));
                    adapter.notifyDataSetChanged();
                })
                .setNegativeButton("Anuluj", null)
                .show();
    }

    private void showEditNoteDialog(int position) {
        Note note = notes.get(position);
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_add_note, null);
        EditText etTitle = dialogView.findViewById(R.id.etTitle);
        EditText etContent = dialogView.findViewById(R.id.etContent);


        etTitle.setText(note.title);
        etContent.setText(note.content);

        new AlertDialog.Builder(this)
                .setTitle("Edytuj notatkę")
                .setView(dialogView)
                .setPositiveButton("Zapisz", (dialog, which) -> {
                    note.title = etTitle.getText().toString();
                    note.content = etContent.getText().toString();
                    adapter.notifyDataSetChanged();
                })
                .setNegativeButton("Anuluj", null)
                .show();
    }
}